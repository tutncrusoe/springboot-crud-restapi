package com.example.springbootcrudrestapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootCrudRestapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
