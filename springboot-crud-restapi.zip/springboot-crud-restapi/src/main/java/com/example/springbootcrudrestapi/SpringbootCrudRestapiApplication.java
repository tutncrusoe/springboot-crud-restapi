package com.example.springbootcrudrestapi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootCrudRestapiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootCrudRestapiApplication.class, args);
	}

}
